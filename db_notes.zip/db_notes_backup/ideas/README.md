## Intro..:
This directory contains **ideas** for ***next** topics i would like to look into.
