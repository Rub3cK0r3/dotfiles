# visual-mode

- Select text for editing, copying, or formatting
- Key points:
  - v: character, V: line, Ctrl-V: block
  - Combine with operators: d, y, >, <
- Common mistakes:
  - Selecting manually instead of using text objects
  - Forgetting to exit visual mode properly
- Related: [[editing]] [[navigation]]

+===+
[[README.md]]
+===+

