# editing

- Modify text efficiently
- Key points:
  - Operators: d, c, y
  - Text objects: aw, iw, ap, ip
  - Undo/redo: u, Ctrl-R
- Common mistakes:
  - Editing without motions
  - Forgetting undo history
- Related: [[navigation]] [[visual-mode]]

+===+
[[README.md]]
+===+

