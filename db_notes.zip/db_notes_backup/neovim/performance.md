# performance

- Optimizing Neovim startup and runtime
- Techniques:
  - Lazy-loading plugins
  - Profiling (`:profile start`)
  - Avoid unnecessary autocommands
- Key points:
  - Measure before optimizing
  - Focus on startup bottlenecks
- Common mistakes:
  - Blindly disabling features
  - Ignoring plugin overhead
- Related: [[plugins.md]] [[automation.md]]

+===+
[[README.md]]
+===+

