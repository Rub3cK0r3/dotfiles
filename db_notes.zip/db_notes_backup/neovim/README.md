## `neovim/intro.md`

```md
# neovim — rub3ck0r3

My **primary interface to text**.

Neovim is not an editor here —  
it’s an environment for thinking.

---

## What lives here

- core motions and habits
- minimal config decisions
- plugin boundaries
- LSP without magic
- keymaps with intent

---

## Rules

- config must be readable
- every plugin justified
- defaults first, hacks last

---

Related:
```md
[[vim-motions]] [[lua]] [[lsp]] [[workflow]]

# 1. Basics & Navigation

[[basics.md]] — fundamental commands, modes, workflow
[[navigation.md]] — motions, marks, searches
[[editing.md]] — insert, delete, change operations
[[visual-mode.md]] — selecting and operating on text

# 2. Automation & Plugins

[[automation.md]] — macros, autocommands, scripting
[[plugins.md]] — plugin management, lazy loading

# 3. Advanced Features

[[lsp.md]] — language servers, autocompletion, diagnostics
[[debugging.md]] — troubleshooting, logging
[[config-structure.md]] — modular init, lazy-loading
[[performance.md]] — profiling, startup optimization
[[keymaps.md]] — custom mappings, workflow design
