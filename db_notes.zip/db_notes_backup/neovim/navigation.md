# navigation

- Move efficiently without leaving keyboard
- Key points:
  - Motions: w, e, b, $, 0
  - Search: /, ?, n, N
  - Marks and jumps: m, `, '
- Common mistakes:
  - Repeating keystrokes unnecessarily
  - Not using registers or marks
- Related: [[basics]] [[editing]] [[visual-mode]]

+===+
[README.md]]
+===+

