# config-structure

- Organizing `init.lua` / `init.vim` and plugin configs
- Concepts:
  - Modular config files
  - Lazy-loading plugins
  - Environment separation
- Key points:
  - Keep config readable
  - Avoid global pollution
- Common mistakes:
  - Monolithic init files
  - Loading everything on startup
- Related: [[plugins.md]] [[automation.md]]

+===+
[[README.md]]
+===+

