# automation

- Save keystrokes with scripts and mappings
- Key points:
  - Keymaps: nnoremap, inoremap, vnoremap
  - Autocommands: event-driven actions
  - Lua config for custom workflows
- Common mistakes:
  - Overcomplicating mappings
  - Ignoring maintainability
- Related: [[plugins]] [[basics]]

+===+
[[README.md]]
+===+

