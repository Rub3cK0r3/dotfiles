# keymaps

- Custom keyboard mappings
- Goals:
  - Reduce friction
  - Encode workflows
- Key points:
  - Muscle memory matters
  - Avoid overwriting defaults unnecessarily
- Common mistakes:
  - Overloading default keys
  - Confusing key sequences
- Related: [[basics.md]] [[editing.md]]

+===+
[[README.md]]
+===+

