# lsp

- Language Server Protocol integration
- Provides:
  - Autocomplete
  - Diagnostics
  - Go-to-definition / references
- Key points:
  - Editor-agnostic protocol
  - Can run multiple servers per filetype
- Common mistakes:
  - Ignoring LSP errors
  - Conflicting server configs
- Related: [[plugins.md]] [[editing.md]]

+===+
[[README.md]]
+===+

