# plugins

- Extend Neovim functionality
- Key points:
  - Keep minimal: quality > quantity
  - Plugin managers: lazy.nvim, packer
  - Common useful types: file explorer, fuzzy finder, syntax, LSP
- Common mistakes:
  - Installing too many plugins
  - Ignoring native capabilities
- Related: [[automation]] [[basics]]

+===+
[[README.md]]
+===+

