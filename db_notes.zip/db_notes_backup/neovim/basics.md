# basics

- Core concepts:
  - Modes: normal, insert, visual, command
  - Buffers, windows, tabs
  - Registers and clipboard
- Common mistakes:
  - Ignoring modes
  - Over-reliance on mouse
- Related: [[navigation]] [[editing]]

+===+
[[EADME.md]]
+===+

