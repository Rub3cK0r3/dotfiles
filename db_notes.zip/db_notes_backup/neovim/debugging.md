# debugging

- Techniques to find and fix issues in Neovim
- Tools:
  - `:checkhealth`
  - `:messages`
  - Logs (`nvim --log`)
- Key points:
  - Isolate plugin issues
  - Reproduce minimal steps
- Common mistakes:
  - Ignoring logs
  - Updating plugins blindly
- Related: [[plugins.md]] [[automation.md]]

+===+
[[README.md]]
+===+

