## `linux/intro.md`

```md
# linux — rub3ck0r3

Notes on the **operating system I live in**.

This is about processes, memory, files, and the tools that expose them.

---

## What lives here

- processes & scheduling
- memory, signals, syscalls
- filesystems and permissions
- networking basics
- debugging from userspace

---

## Philosophy

- know what the kernel does
- read man pages, then source
- tools are interfaces to the OS

---

Related:
```md
[[process]] [[filesystem]] [[networking]] [[debugging]]

---

## INDEX

# 1. Processes & Scheduling

[[processes.md]] — lifecycle, scheduling, signals
[[signals.md]] — notifications, handling, default actions
[[memory.md]] — virtual memory, paging, swapping
[[containers-basics.md]] — namespaces, cgroups, isolation

# 2. Filesystems & IO

[[filesystems.md]] — mounting, ext4, permissions, journaling
[[io.md]] — disk, socket, async/blocking models

# 3. Networking

[[networking.md]] — TCP/IP, sockets, routing, firewalls

# 4. Security & Permissions

[[permissions.md]] — user/group, chmod, ACLs
[[users-groups.md]] — accounts, groups, UID/GID

# 5. Boot & Init

[[boot-process.md]] — BIOS → kernel → init
[[systemd.md]] — units, dependencies, logging

# 6. Performance & Debugging

[[performance.md]] — profiling, bottlenecks, tuning
[[debugging.md]] — gdb, strace, logs
