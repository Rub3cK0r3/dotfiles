# signals

- Messages sent to processes for control
- Key points:
  - SIGTERM, SIGKILL, SIGHUP, SIGSTOP
  - Handle signals safely
  - Foreground vs background effect
- Common mistakes:
  - Killing parent accidentally
  - Ignoring signals in scripts
- Related: [[processes.md]] [[performance.md]]

+===+
[[README.md]]
+===+
