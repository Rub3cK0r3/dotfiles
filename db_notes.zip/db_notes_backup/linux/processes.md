# processes

- A running program with memory + CPU context
- Key points:
  - PID identifies process
  - Parent/child relationships
  - Foreground vs background
- Common mistakes:
  - Orphaned or zombie processes
  - Confusing threads vs processes
- Related: [[signals.md]] [[performance.md]] [[permissions.md]]

+===+
[[README.md]]
+===+
