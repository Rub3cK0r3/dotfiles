# io

- Interaction with disks, sockets, devices
- Models:
  - Blocking
  - Non-blocking
  - Async
- Key points:
  - IO is usually the bottleneck
- Common mistakes:
  - Blocking IO in hot paths
  - Ignoring file descriptor limits
- Related: [[networking.md]] [[performance.md]]

+===+
[[README.md]]
+===+

