# containers-basics

- Lightweight virtualization
- Concepts:
  - Namespaces (pid, mount, net)
  - Control groups (CPU, memory)
- Key points:
  - Isolation ≠ security
  - Resource limits prevent runaway processes
- Common mistakes:
  - Not cleaning up containers/images
  - Confusing container networking with host
- Related: [[processes.md]] [[networking.md]]

+===+
[[README.md]]
+===+

