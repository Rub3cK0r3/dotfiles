# users-groups

- User and group management
- Concepts:
  - UID / GID
  - /etc/passwd, /etc/group
  - Permissions (rwx)
- Key points:
  - Principle of least privilege
- Common mistakes:
  - Using root for normal tasks
  - Misconfigured permissions
- Related: [[permissions.md]] [[security.md]]

+===+
[[README.md]]
+===+

