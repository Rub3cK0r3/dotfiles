# filesystems

- Organize and persist data
- Concepts:
  - Paths, directories, symbolic/hard links
  - Mount points, filesystems types
- Key points:
  - Absolute vs relative paths
  - Permissions matter for security
- Common mistakes:
  - Misusing symlinks
  - Ignoring mount options
- Related: [[permissions.md]] [[performance.md]]

+===+
[[README.md]]
+===+
