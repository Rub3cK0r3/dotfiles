# systemd

- Init system and service manager
- Concepts:
  - Units (service, socket, target)
  - Dependencies and ordering
- Key points:
  - Services can be restarted automatically
  - Unit files control execution environment
- Common mistakes:
  - Ignoring logs from `journalctl`
  - Overcomplicated dependencies
- Related: [[boot-process.md]] [[processes.md]]

+===+
[[README.md]]
+===+

