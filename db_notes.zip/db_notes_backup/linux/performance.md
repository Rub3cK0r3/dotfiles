# performance

- How system resources are used
- Key points:
  - CPU, memory, disk I/O, network
  - Profiling with top/htop/iostat
  - Identifying bottlenecks
- Common mistakes:
  - Ignoring resource contention
  - Optimizing without measurement
- Related: [[processes.md]] [[signals.md]] [[networking.md]]

+===+
[[README.md]]
+===+
