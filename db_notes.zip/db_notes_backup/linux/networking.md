# networking

- How processes communicate over networks
- Key points:
  - Sockets, ports, protocols
  - Loopback vs external interfaces
  - Firewalls and access control
- Common mistakes:
  - Hardcoding IPs/ports
  - Ignoring network errors
- Related: [[processes.md]] [[performance.md]]

+===+
[[README.md]]
+===+
