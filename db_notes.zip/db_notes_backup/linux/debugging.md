# debugging

- Tools and techniques to inspect running programs
- Key points:
  - `strace` / `ltrace` — trace syscalls and library calls
  - `gdb` — step through code, inspect memory, set breakpoints
  - `perf` — profile CPU/memory usage
  - `/proc` — kernel interface for live process info
- Common mistakes:
  - Attaching debugger to wrong PID
  - Forgetting to run program with correct permissions
  - Overlooking signals affecting program flow
- Related: [[processes.md]] [[signals.md]] [[performance.md]]

+===+
[[README.md]]
+===+

