# permissions

- Who can do what to files/processes
- Key points:
  - Read/Write/Execute bits
  - Users, groups, ownership
  - SUID/SGID/sticky bits
- Common mistakes:
  - Overly permissive files
  - Confusing user vs group rights
- Related: [[filesystems.md]] [[processes.md]]

+===+
[[README.md]]
+===+
