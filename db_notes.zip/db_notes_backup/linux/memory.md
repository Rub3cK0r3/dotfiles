# memory

- Virtual memory abstraction
- Concepts:
  - Pages
  - Page faults
  - Swapping
- Key points:
  - Memory ≠ RAM
  - Overcommit exists
- Common mistakes:
  - Assuming OOM = crash
  - Forgetting to free resources
- Related: [[processes.md]] [[performance.md]]

+===+
[[README.md]]
+===+

