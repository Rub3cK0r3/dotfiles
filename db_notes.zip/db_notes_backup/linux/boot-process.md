# boot-process

- Steps from power-on to login
- Phases:
  - BIOS / UEFI
  - Bootloader (GRUB, LILO)
  - Kernel initialization
  - Init/systemd
- Key points:
  - Early logging critical for debugging
- Common mistakes:
  - Misconfiguring init targets
  - Ignoring boot-time errors
- Related: [[processes.md]] [[systemd.md]]

+===+
[[README.md]]
+===+

