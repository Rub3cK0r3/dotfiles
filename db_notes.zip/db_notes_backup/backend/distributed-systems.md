# distributed systems

- Systems running across multiple machines that appear as one logical system
- Key points:
  - Consensus algorithms: Raft, Paxos
  - Leader election, quorum-based writes
  - Replication strategies: master-slave, multi-master
  - Partitioning/sharding for scaling
  - CAP theorem tradeoffs: Consistency, Availability, Partition tolerance
  - Idempotency for retries and fault tolerance
  - Eventual consistency patterns
  - Distributed transactions and coordination
- Common mistakes:
  - Assuming perfect network reliability
  - Not planning for network partitions
  - Ignoring clock skew and ordering issues
  - Overlooking cascading failures
- Related: [[database.md]] [[data-consistency.md]] [[scalability.md]] [[background-jobs.md]]

+===+
[[README.md]]
+===+

