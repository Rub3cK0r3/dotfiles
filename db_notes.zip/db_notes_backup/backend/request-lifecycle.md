# request-lifecycle

- Path a request takes: entry → routing → middleware → handler → response
- Key points:
  - Order matters (middleware, side effects)
  - Errors propagate top-down
  - Side effects should be isolated
- Common mistakes:
  - Heavy computation before auth
  - Mixing unrelated logic
- Related: [[error-handling.md]] [[auth-vs-authz.md]] [[logging-monitoring.md]]

+===+
[[README.md]]
+===+
