# api-design

- Principles for server contracts
  - Clear inputs/outputs
  - Stateless when possible
  - Versioning for change
- Tradeoffs:
  - Flexibility vs stability
  - Granularity vs performance
- Related: [[request-lifecycle.md]] [[server-state.md]] [[caching.md]]

+===+
[[README.md]]
+===+


