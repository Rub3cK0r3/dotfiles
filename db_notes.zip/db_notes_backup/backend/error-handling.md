# error-handling

- Failures happen, plan for them
- Patterns:
  - Centralized error handler
  - Graceful degradation
  - Logging & monitoring
- Common mistakes:
  - Swallowing errors
  - Mixing business + system errors
- Related: [[request-lifecycle.md]] [[logging-monitoring.md]]

+===+
[[README.md]]
+===+
