# idempotency

- Same request can be safely repeated
- Critical for:
  - Retries
  - Network failures
  - Background jobs
- Techniques:
  - Idempotency keys
  - Natural keys (PUT semantics)
- Common mistakes:
  - Side effects before deduplication
  - Time-limited idempotency storage
- Related: [[error-handling.md]] [[background-jobs.md]]

+===+
[[README.md]]
+===+

