# data-consistency

- How data stays correct over time
- Patterns:
  - ACID (strong consistency)
  - Eventual consistency (distributed)
- Key ideas:
  - Transactions
  - Conflict resolution
- Common mistakes:
  - Ignoring race conditions
  - Over-relying on eventual consistency
- Related: [[server-state.md]] [[caching.md]] [[scalability.md]]

+===+
[[README.md]]
+===+


