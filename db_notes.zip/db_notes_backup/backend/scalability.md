# scalability

- Scaling = handling more load
- Approaches:
  - Vertical: bigger machine
  - Horizontal: more machines
- Considerations:
  - Stateless services scale easier
  - Bottlenecks: DB, network, CPU
- Common mistakes:
  - Premature scaling
  - Ignoring single points of failure
- Related: [[server-state.md]] [[caching.md]] [[background-jobs.md]]

+===+
[[README.md]]
+===+


