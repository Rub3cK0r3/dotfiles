# server-state

- Where state lives: memory, DB, cache
- Types:
  - Stateless: easy to scale
  - Stateful: needed for sessions, queues
- Common mistakes:
  - Mixing persistent + ephemeral state
  - Inconsistent writes
- Related: [[caching.md]] [[auth-vs-authz.md]] [[data-consistency.md]]

+===+
[[README.md]]
+===+
