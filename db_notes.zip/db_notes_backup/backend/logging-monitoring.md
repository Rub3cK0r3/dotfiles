# logging-monitoring

- Observability = knowing system state
- Components:
  - Logs, metrics, alerts
- Key points:
  - Logs for diagnosis
  - Metrics for trends
  - Alerts for anomalies
- Common mistakes:
  - Too verbose / too sparse
  - Logs without context
- Related: [[error-handling.md]] [[request-lifecycle.md]]

+===+
[[README.md]]
+===+
