# async

- Run tasks without blocking main flow
- Patterns:
  - Async/await
  - Background jobs / queues
- Common mistakes:
  - Ignoring errors in async code
  - Overcomplicating flows

## Related

[[request-lifecycle.md]]  
[[caching.md]]  
[[database.md]]

+===+
[[README.md]]
+===+


