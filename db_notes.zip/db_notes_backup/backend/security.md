# security

- Protecting systems, data, and users from unauthorized access or abuse
- Key points:
  - Authentication: passwords, tokens, OAuth2, OpenID Connect
  - Authorization: RBAC, ABAC, least privilege
  - Transport encryption: TLS, HTTPS
  - Data encryption at rest
  - Secret management: keys, tokens, rotations
  - Rate limiting and throttling to prevent abuse
  - Logging and audit trails for security events
  - Secure defaults and fail-safe configurations
- Common mistakes:
  - Storing passwords in plaintext
  - Hardcoding secrets in code
  - Ignoring session expiration or revocation
  - Overlooking edge-case attack vectors (replay, injection)
- Related: [[auth-vs-authz.md]] [[server-state.md]] [[caching.md]] [[logging-monitoring.md]]

+===+
[[README.md]]
+===+

