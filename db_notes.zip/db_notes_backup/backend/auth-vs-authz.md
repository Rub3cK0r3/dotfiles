# auth-vs-authz

- Authentication: who you are
- Authorization: what you can do
- Patterns:
  - Token-based, session-based
  - Role-based, attribute-based
- Common mistakes:
  - Confusing auth vs authz
  - Hardcoding roles
- Related: [[request-lifecycle.md]] [[server-state.md]] [[security.md]]

+===+
[[README.md]]
+===+


