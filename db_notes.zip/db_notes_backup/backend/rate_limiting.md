# rate-limiting

- Control request volume per client or key
- Used for:
  - Abuse prevention
  - Fair resource usage
  - Cost control
- Common strategies:
  - Token bucket
  - Leaky bucket
  - Fixed / sliding windows
- Key points:
  - Must be cheap to evaluate
  - Usually enforced at the edge
- Common mistakes:
  - Global limits instead of per-identity
  - No burst allowance
- Related: [[security.md]] [[scalability.md]]

+===+
[[README.md]]
+===+

