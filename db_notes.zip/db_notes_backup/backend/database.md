# database

- Store persistent data
- Concepts:
  - SQL vs NoSQL
  - Transactions
  - Indexes
- Common mistakes:
  - N+1 queries
  - Ignoring constraints

## Related

[[async.md]]  
[[caching.md]]  
[[api-design.md]]

+===+
[[README.md]]
+===+


