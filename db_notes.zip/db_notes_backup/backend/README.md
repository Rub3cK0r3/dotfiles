# backend — rub3ck0r3

Notes on **building, breaking, and understanding servers**.

This is about how systems behave under load, failure, and abuse —  
not frameworks for the sake of frameworks.

---

## What lives here

- APIs (REST, RPC, async)
- auth, sessions, tokens
- databases & data modeling
- performance and bottlenecks
- distributed systems basics
- tradeoffs and failure modes

---

## Focus

- correctness before scale
- boring tech that survives
- understanding > abstraction
- read the spec, then the code

---

## How notes are written

- problem → constraints → solution
- diagrams in head, text on disk
- assumptions stated explicitly

## INDEX

# 1. APIs & Request Lifecycle

[[api-design.md]] — REST vs RPC, resource modeling, versioning, REST vs RPC
[[request-lifecycle.md]] — request flow, middleware, context propagation
[[async.md]] — async execution, queues, workers, event-driven patterns
[[error-handling.md]] — failure modes, retries, graceful degradation
[[idempotency.md]] — safe retries, deduplication

# 2. Auth & Security

[[auth-vs-authz.md]] — identity vs permissions, RBAC/ABAC, trust boundaries
[[security.md]] — threat models, secrets, encryption, rate limiting, abuse prevention
[[rate-limiting.md]] — controlling request volume per client or key

# 3. Databases & Caching

[[database.md]] — data modeling, indexes, transactions, query planning
[[data-consistency.md]] — ACID, eventual consistency, conflict resolution
[[caching.md]] — cache-aside patterns, invalidation, hot vs cold data
[[migrations.md]] — controlled schema evolution, versioning

# 4. Performance & Scalability

[[scalability.md]] — horizontal scaling, sharding, load balancing
[[background-jobs.md]] — async work, retries, backoff, failure isolation

# 5. Reliability & Observability

[[error-handling.md]] — failure modes, retries, graceful degradation
[[logging-monitoring.md]] — logs, metrics, tracing, SLOs
[[server-state.md]] — stateless services, session storage, replication impact

# 6. Distributed Systems

[[distributed-systems.md]] — replication, consensus, partitions, coordination
