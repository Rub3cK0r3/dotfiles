# migrations

- Controlled evolution of schemas
- Goals:
  - Backward compatibility
  - Zero downtime
- Patterns:
  - Expand → migrate → contract
  - Versioned migrations
- Common mistakes:
  - Destructive changes
  - App + schema deployed together
- Related: [[database.md]] [[data-consistency.md]]

+===+
[[README.md]]
+===+

