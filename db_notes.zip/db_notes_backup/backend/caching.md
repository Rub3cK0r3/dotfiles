# caching

- Purpose: reduce repeated work, improve performance
- Types:
  - In-memory, DB, CDN, HTTP-level
- Key ideas:
  - Invalidation strategy
  - Cache vs source of truth
- Common mistakes:
  - Stale data, over-caching
- Related: [[server-state.md]] [[api-design.md]] [[data-consistency.md]]

+===+
[[README.md]]
+===+
