# background-jobs

- Async tasks outside main request flow
- Patterns:
  - Queues, workers
  - Scheduled jobs
- Key points:
  - Idempotence
  - Retry strategy
- Common mistakes:
  - Mixing sync + async logic
  - Ignoring failure handling
- Related: [[server-state.md]] [[error-handling.md]] [[scalability.md]]

+===+
[[README.md]]
+===+
