# intro — rub3ck0r3

Personal knowledge base written in **plain Markdown**.  
Built for **Neovim**, **Linux**, and people who prefer thinking over tooling.

No cloud. No lock-in. Just text.

---

## What this is

This is my **technical brain dump**:
- backend engineering
- security (as a serious hobby)
- Linux, systems and internals
- optimization, efficiency, minimalism
- notes from learning, breaking and rebuilding things

Everything lives as `.md` files.
If it can’t survive without an app, it doesn’t belong here.

---

## Core areas

- [[backend]]
- [[security]]
- [[linux]]
- [[neovim]]
- [[ideas]]

Each link points to a file or a directory acting as an entry point.

---

## Philosophy

- Text over UI
- Keyboard over mouse
- Simple files over complex systems
- Search > navigation
- Learn by doing
- Document what matters, drop the rest

This is not a productivity system.  
It’s a **working notebook for an autodidact**.

---

## How notes are written

- Short and direct
- One concept per file when possible
- Lists and code > long explanations
- Link ideas using `[[notes]]`

Example:
```md
Related: [[auth]] [[jwt]] [[oauth]] [[attack-surface]]
