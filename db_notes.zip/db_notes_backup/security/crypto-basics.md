# crypto-basics

- Protect data confidentiality and integrity
- Primitives:
  - Hashing
  - Symmetric / asymmetric encryption
  - Signatures
- Key points:
  - Use well-tested libraries
  - Never roll your own crypto
- Common mistakes:
  - Hardcoded keys
  - Weak algorithms
- Related: [[secure-storage.md]] [[auth-models.md]]

+===+
[[README.md]]
+===+

