# defense-in-depth

- Multiple layers of protection
- Key points:
  - Don’t rely on a single control
  - Layer: network, app, database, user
  - Fail securely
- Common mistakes:
  - Assuming one check is enough
  - Inconsistent policies across layers
- Related: [[threat-modeling]] [[vuln-classes]] [[trust-boundaries]]

+===+
[[README.md]]
+===+

