# incident-response

- Handling security incidents
- Steps:
  - Detection
  - Containment
  - Eradication
  - Recovery
  - Postmortem
- Key points:
  - Have a documented plan
  - Communication is critical
- Common mistakes:
  - Panic-driven response
  - No lessons learned
- Related: [[trust-boundaries.md]] [[defense-in-depth.md]]

+===+
[[README.md]]
+===+

