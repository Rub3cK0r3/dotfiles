# key-management

- Manage encryption keys securely
- Concepts:
  - Rotation
  - Storage (HSM, vault)
  - Revocation
- Key points:
  - Separate keys from data
  - Limit access
- Common mistakes:
  - Hardcoding keys
  - No rotation strategy
- Related: [[crypto-basics.md]] [[secure-storage.md]]

+===+
[[README.md]]
+===+

