# secure-storage

- Safe storage of secrets and sensitive data
- Examples:
  - API keys
  - Passwords
  - Tokens
- Key points:
  - Encrypt at rest
  - Limit access scope
- Common mistakes:
  - Storing secrets in source code
  - Improper permissions on files
- Related: [[crypto-basics.md]] [[trust-boundaries.md]]

+===+
[[README.md]]
+===+

