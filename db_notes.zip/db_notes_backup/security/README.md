# security — rub3ck0r3

Security as a **way of thinking**, not a checklist.

This is a serious hobby:
understanding how systems fail under adversarial pressure.

---

## What lives here

- threat modeling
- auth and identity failures
- common vulnerability classes
- exploitation fundamentals
- defensive design patterns

---

## Mindset

- assume compromise
- trust boundaries matter
- complexity is the enemy
- attackers read docs too

---

Related:
```md
[[threat-model]] [[auth]] [[vulnerabilities]] [[attack-surface]]

## INDEX

# 1. Authentication & Identity

[[auth-models.md]] — RBAC, ABAC, identity vs permissions
[[auth-flows.md]] — password, OAuth/OIDC, MFA

# 2. Threat Modeling & Defense

[[defense-in-depth.md]] — layered security approach
[[trust-boundaries.md]] — isolating sensitive components
[[thread-modeling.md]] — threat analysis, attacker capabilities
[[vuln-types.md]] — common vulnerability classes

# 3. Crypto & Secrets

[[crypto-basics.md]] — hashing, encryption, signatures
[[key-management.md]] — rotation, storage, revocation
[[secure-storage.md]] — storing secrets safely

# 4. Input & Validation

[[input-validation.md]] — sanitize, validate, encode

# 5. Incident Handling

[[incident-response.md]] — detection, containment, postmortem
