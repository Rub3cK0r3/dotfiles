# trust-boundaries

- Points where data/control crosses security boundaries
- Key points:
  - Authenticate & validate at every boundary
  - Treat untrusted inputs as hostile
- Common mistakes:
  - Implicit trust in internal services
  - Skipping checks at API boundaries
- Related: [[threat-modeling]] [[input-validation]] [[auth-models]]

+===+
[[README.md]]
+===+

