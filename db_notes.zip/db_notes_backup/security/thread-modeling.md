# threat-modeling

- Identify what can go wrong before it happens
- Key points:
  - Consider attacker goals
  - Map assets, entry points, and trust levels
  - Prioritize threats by impact
- Common mistakes:
  - Focusing on known attacks only
  - Ignoring low-probability high-impact threats
- Related: [[trust-boundaries]] [[auth-models]] [[defense-in-depth]]

+===+
[[README.md]]
+===+

