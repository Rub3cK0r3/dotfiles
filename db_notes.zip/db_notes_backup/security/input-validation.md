# input-validation

- Never trust external input
- Key points:
  - Validate type, length, format
  - Escape or sanitize before use
- Common mistakes:
  - Relying only on frontend validation
  - Inconsistent validation across endpoints
- Related: [[auth-models]] [[trust-boundaries]] [[vuln-classes]]

+===+
[[README.md]]
+===+

