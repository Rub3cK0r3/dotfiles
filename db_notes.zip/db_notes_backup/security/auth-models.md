# auth-models

- How users and systems prove identity & access
- Concepts:
  - Authentication: who you are
  - Authorization: what you can do
  - Session vs token models
- Common mistakes:
  - Confusing auth with authz
  - Hardcoding roles or credentials
- Related: [[trust-boundaries.md]] [[threat-modeling.md]]

+===+
[[README.md]]
+===+

