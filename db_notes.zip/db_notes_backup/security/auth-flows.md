# auth-flows

- Patterns for authentication
- Types:
  - Password-based
  - OAuth/OIDC
  - Multi-factor
- Key points:
  - Always verify identity
  - Expire sessions/tokens appropriately
- Common mistakes:
  - Weak password policies
  - Storing passwords in plaintext
- Related: [[auth-models.md]] [[trust-boundaries.md]]

+===+
[[README.md]]
+===+

