# vuln-types

- Common attack categories
  - Injection (SQL, command)
  - XSS/CSRF
  - Broken auth/session
  - Misconfig & info leaks
- Key points:
  - Learn patterns, not just CVEs
  - Map vulnerabilities to trust boundaries
- Common mistakes:
  - Ignoring minor issues → chaining attacks
  - Overlooking default configs
- Related: [[input-validation]] [[defense-in-depth]]

+===+
[[README.md]]
+===+

