# caching

- Reduce repeated network requests
- Types:
  - HTTP cache
  - Service worker cache
  - Memory / local storage
- Key points:
  - Invalidate stale data
  - Respect freshness / TTL
- Common mistakes:
  - Over-caching dynamic content
  - Ignoring cache invalidation
- Related: [[data-fetching.md]] [[performance.md]]

+===+
[[README.md]]
+===+

