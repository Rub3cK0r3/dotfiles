# side-effects

- Anything affecting outside world:
  - Network calls
  - Logging
  - DOM manipulation
- Key points:
  - Isolate from rendering
  - Keep deterministic UI logic pure
- Common mistakes:
  - Triggering network calls on every render
  - Changing state directly inside effect
- Related: [[state.md]] [[rendering.md]] [[client-server-boundary.md]]

+===+
[[README.md]]
+===+

