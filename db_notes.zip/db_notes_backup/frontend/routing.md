# routing

- Maps URLs to views/components
- Concepts:
  - URL = state of app
  - Routes as declarative mapping
- Key points:
  - Preserve state across navigation
  - Guard sensitive routes
- Common mistakes:
  - Storing navigation state in random components
  - Ignoring back/forward behavior
- Related: [[client-server-boundary.md]] [[state.md]]

+===+
[[README.md]]
+===+

