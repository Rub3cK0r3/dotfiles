## `frontend/intro.md`

```md
# frontend — rub3ck0r3

Frontend as **systems and constraints**, not aesthetics.

This is about how browsers work, how users break things,
and how state becomes chaos.

---

## What lives here

- browser internals
- JS runtime behavior
- rendering and performance
- state management patterns
- security at the edge
- accessibility when it matters

---

## Philosophy

- understand the platform
- minimal dependencies
- predictable state > clever tricks
- fast by design, not tuning

---

# 1. Core Concepts

[[basics.md]] — architecture, rendering flow, component model
[[client-server-boundary.md]] — what runs where
[[state.md]] — managing local and global state
[[side-effects.md]] — effects outside rendering, async updates

# 2. Routing & Rendering

[[routing.md]] — navigation, URL mapping, nested routes
[[rendering.md]] — SSR vs CSR vs SSG, hydration
[[data-fetching.md]] — fetching, caching, loading states
[[caching.md]] — HTTP, SW, memory caching

# 3. Forms & Accessibility

[[forms.md]] — user input handling, validation
[[accessibility.md]] — semantic HTML, keyboard navigation, screen readers

# 4. Performance & Observability

[[performance.md]] — render performance, profiling
[[observability.md]] — metrics, error tracking, user monitoring
[[error-handling.md]] — fail soft, logs, retries

# 5. Testing

[[testing.md]] — unit, integration, end-to-end
