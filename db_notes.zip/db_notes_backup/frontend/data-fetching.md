# data-fetching

- How data moves from server to UI
- Concerns:
  - Loading states
  - Errors
  - Caching
- Key points:
  - Fetch close to where data is used
  - Avoid duplicate requests
- Common mistakes:
  - Fetching in deeply nested components
  - No retry or timeout handling
- Related: [[state.md]] [[side-effects.md]] [[performance.md]]

+===+
[[README.md]]
+===+

