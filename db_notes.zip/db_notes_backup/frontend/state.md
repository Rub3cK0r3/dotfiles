# state

- Holds app data over time
- Types:
  - Local: component-level
  - Derived: computed from other state
  - Global: shared across app
- Key points:
  - Avoid duplication
  - Keep source of truth clear
- Common mistakes:
  - Mixing local + global state inconsistently
  - Overusing mutable shared state
- Related: [[rendering.md]] [[side-effects.md]] [[client-server-boundary.md]]

+===+
[[README.md]]
+===+

