# client-server-boundary

- Where client stops and server starts
- Key points:
  - API contracts
  - Data validation at boundary
  - Avoid trusting client data blindly
- Common mistakes:
  - Leaking server logic to client
  - Overfetching or underfetching data
- Related: [[state.md]] [[side-effects.md]] [[api-design.md]]

+===+
[[README.md]]
+===+

