# rendering

- How UI updates in response to data/state
- Models:
  - Imperative: tell UI exactly what to do
  - Declarative: describe desired state
- Key points:
  - Avoid unnecessary re-renders
  - Keep side effects separate
- Common mistakes:
  - Updating state in multiple places
  - Rendering expensive computations inline
- Related: [[state.md]] [[side-effects.md]] [[performance.md]]

+===+
[[README.md]]
+===+

