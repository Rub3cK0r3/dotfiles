# error-handling

- User-visible vs silent failures
- Sources:
  - Network
  - Rendering
  - Logic
- Key points:
  - Fail soft when possible
  - Log with context
- Common mistakes:
  - Blank screens
  - Swallowing errors
- Related: [[side-effects.md]] [[performance.md]]

+===+
[[README.md]]
+===+

