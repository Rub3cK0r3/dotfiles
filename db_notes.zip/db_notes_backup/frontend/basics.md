# basics

- Core frontend architecture concepts
- Components:
  - Reusable UI units
  - Props vs state
- Rendering flow:
  - Virtual DOM / reactive updates
  - Reconciliation
- Key points:
  - Keep components small and focused
  - Minimize unnecessary renders
- Common mistakes:
  - Mutating state directly
  - Heavy computation in render
- Related: [[state.md]] [[rendering.md]] [[side-effects.md]]

+===+
[[README.md]]
+===+

