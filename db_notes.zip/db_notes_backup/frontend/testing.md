# testing

- Ensure correctness of UI and logic
- Types:
  - Unit
  - Integration
  - End-to-end
- Key points:
  - Automate critical paths
  - Mock external dependencies
- Common mistakes:
  - Over-testing trivial code
  - Ignoring flaky tests
- Related: [[state.md]] [[data-fetching.md]]

+===+
[[README.md]]
+===+

