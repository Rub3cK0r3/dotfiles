# forms

- User input handling
- Key points:
  - Controlled vs uncontrolled inputs
  - Validation and feedback
- Common mistakes:
  - Not sanitizing input
  - Mixing presentation and state logic
- Related: [[state.md]] [[data-fetching.md]]

+===+
[[README.md]]
+===+

