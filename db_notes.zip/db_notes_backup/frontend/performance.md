# performance

- Optimizing perceived and real app speed
- Key points:
  - Avoid unnecessary renders
  - Lazy-load resources
  - Debounce/throttle frequent updates
- Common mistakes:
  - Premature optimization
  - Forgetting measurement
- Related: [[rendering.md]] [[state.md]] [[side-effects.md]]

+===+
[[README.md]]
+===+

