# accessibility

- Make UI usable for all users
- Core ideas:
  - Semantic HTML
  - Keyboard navigation
  - Screen readers
- Key points:
  - Accessibility is structural
- Common mistakes:
  - Click-only interactions
  - Color-only signals
- Related: [[rendering.md]] [[state.md]]

+===+
[[README.md]]
+===+

